//
//  ViewController.swift
//  ExameniOSAbdiel
//
//  Created by Abdiel Molina on 30/12/20.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var numberText: UITextField!
    @IBOutlet weak var actionButton1: UIButton!
    @IBOutlet weak var actionButton2: UIButton!
    @IBOutlet weak var result: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        actionButton1.layer.cornerRadius = 25
        actionButton2.layer.cornerRadius = 25
        
    }
    
    func isCousinNumber(){
        let str = numberText.text ?? ""
        let number = Int(str) ?? 0
        var isPrime = true
        
        if number <= 0 {
            result.text = "Debes introducir un numero positivo"
        }else {
            if number % 2 == 0 || number % 3 == 0 {
                isPrime = true
            }
            else {
                isPrime = false
            }
        }
        
        if isPrime == true{
            if number <= 0 {
                result.text = "No es primo"
            }else{
                result.text = "Es Primo"
                
            }
        }else{
        
            if number <= 0 {
                result.text = "No es primo"
            }else{
                result.text = "No es primo"
                
            }        }
        
        
    }
   
    
    @IBAction func actionButtonFunc1(_ sender: Any) {
        isCousinNumber()
    }
    
}

